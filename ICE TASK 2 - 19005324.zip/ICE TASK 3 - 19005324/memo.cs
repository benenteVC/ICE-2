﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICETASK3
{
    public class memo
    {
        private string state;

        public memo(string state)
        {
            this.state = state;
        }

        public string State { get => state; }
    }
}
