﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ICETASK3

{
    public partial class MainWindow : Window
    {
        private string state;
        private Caretaker ct = new Caretaker();
        private Stack<DateTime> timeStamps = new Stack<DateTime>();
        
        public MainWindow()
        {
            InitializeComponent();
            state = txbContent.Text;
        }
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            saveToMemento();
        }


        private void btnUndo_Click(object sender, RoutedEventArgs e)
        {
            Memento m = ct.GetMemento();
            getStateFromMemento(m);
            lblStatus.Content = "Status :items have been changed to {timeStamps()}";
        }
        public Memento saveToMemento() 
        {
            state = txbContent.Text;
            return new Memento(state);
        }

        public void getStateFromMemento(Memento memento) 
        {
            state = memento.State;
            txbContent.Text = state;
        }


    }
}
